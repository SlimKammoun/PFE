# -*- coding: utf-8 -*-
"""
Created on Wed Feb 15 22:10:01 2017

@author: slim
"""
import numpy as np
import math
### dimentions 1 

### paramètres 
n=10000
pas=1  # nombre d'échantillion 
T_max=20   # temps 
Lambda =10 #paramètre poisson 

pareto=4 #paramètre pareto
## simulation cas poisson 
sd_poisson =[]
for TT in range (pas,T_max,pas):
    T=2**TT
    H=[]
    print T
    for i in range(n):
        s=0 
        h=-1
        while (s<T):
            s += np.random.poisson(Lambda)
            h=h+1
        H.append(h)
    H=(np.array(H)-T/Lambda)
    sd_poisson.append( np.log(np.std(H)*Lambda)/np.log(T))
    print( np.log(np.std(H)*Lambda)/np.log(T))
   
sd_pareto=[]
for T in range (pas,T_max,pas):
    H=[]
    print T
    for i in range(n):
        s=0 
        h=-1
        while (s<T):
#            s += np.random.pareto(pareto)
            s+=  np.random.exponential(100)
            h=h+1
        H.append(h)
    H=np.array(H)
    sd_pareto.append(np.log(np.std(H)))
    print np.log(np.std(H)*math.sqrt(100))/np.log(T)
