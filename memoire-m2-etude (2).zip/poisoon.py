# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 13:54:54 2017

processus de poisson
@author: mkammoun.lct
"""

import numpy as np
import matplotlib.pyplot as pl
theta =4
def verif(a):
    for i in range(len(a)-1):
        if a[i+1]<a[i]:
            return False
    return True
## generation du nombre de points 
n= np.random.poisson(theta**2)
## génération des points 
points =[np.array(sorted(np.random.uniform(0,theta,n))),np.random.uniform(0,theta,n)]
pl.plot(points[0],points[1],'rp')
s=[]
number=0
from itertools import combinations, chain
allsubsets = lambda n: list(chain(*[combinations(range(n), ni) for ni in range(n+1)]))
test=allsubsets(n)
for i in test :
    a=points[1][list(i)]
    if verif(a) and len(a)>number:
        number=len(a)
        s=i
a=points[0][list(s)]
b=points[1][list(s)]
pl.plot([0,a[0]],[0,b[0]],"b")
pl.plot(points[0][list(s)],points[1][list(s)],"b")
pl.plot([theta,a[-1]],[theta,b[-1]],"b")

pl.show()    